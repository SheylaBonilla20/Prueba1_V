<scrip setup>

</scrip>

<template>
    <footer class="bg-dark mt-5 py-5">
        <div class="container-xl">
            <p class="text-white text-center fs-4 mt-4 m-md-0">SportsShey - Todos los derechos Reservados</p>
        </div>
    </footer>
</template>