<script setup>
  import { ref, reactive, onMounted} from 'vue'
  import { db } from './data/articulos'
  import Articulo from './components/Articulo.vue'
  import Header from './components/Header.vue'
  import Footer from './components/Footer.vue'

  const articulos = ref([])
  const carrito = ref([])
  const articulo = ref({})

  onMounted( () =>{
    articulos.value = db;
    articulo.value = db[3];
  })

  const agregarCarrito = (articulo) =>{

    const existeCarrito = carrito.value.findIndex(producto => producto.id === articulo.id)
    
    if(existeCarrito >= 0){
      carrito.value[existeCarrito].cantidad++
    }else{
      articulo.cantidad = 1
      carrito.value.push(articulo);
    }
  }

  const decrementarCantidad = (id) => {
    const index = carrito.value.findIndex(producto => producto.id === id)
    if(carrito.value[index].cantidad <= 1) return 
    carrito.value[index].cantidad--
  }

  const incrementarCantidad = (id) => {
    const index = carrito.value.findIndex(producto => producto.id === id)
    carrito.value[index].cantidad++
  }

  const eliminarProducto = (id) => {
    carrito.value = carrito.value.filter(producto => producto.id !== id)
  }

    const vaciarCarrito = () => {
    carrito.value = []
  }

</script>

<template>
  <!--Renderizacion del Header-->
  <Header 
    :carrito="carrito"
    :articulo="articulo"
    @decrementar-cantidad="decrementarCantidad"
    @incrementar-cantidad="incrementarCantidad"
     @vaciar-carrito="vaciarCarrito"
    @eliminar-producto="eliminarProducto"
    @agregar-carrito="agregarCarrito"
  />

  <main class="container-xl mt-5">
    <h2 class="text-center">¡Mira nuestras ofertas!</h2>

    <div class="row mt-5">
      <!--Renderizacion-->
      <Articulo 
            v-for="articulo in articulos"
           :articulo = "articulo" 
           @agregar-carrito="agregarCarrito"
        />
        </div>
  </main>

  <!--Renderizacion del Footer-->
  <Footer/>
  
</template>

<style scoped>
  h1{
    text-transform: uppercase;
    color: green;
  }

</style>
